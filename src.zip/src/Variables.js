export const variables={
   API_URL:"http://prototipoenv.eba-tdhde96g.us-west-2.elasticbeanstalk.com/",
   PHOTO_URL:"http://prototipoenv.eba-tdhde96g.us-west-2.elasticbeanstalk.com/Photos/"
}